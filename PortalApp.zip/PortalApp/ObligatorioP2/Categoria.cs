﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Categoria
    {
        //ATRIBUTOS
        #region ATRIBUTOS CATEGORIA
        private int id;
        private string nombre;
        private string descripcion;
        #endregion

        //METODOS
        #region MÉTODOS CATEGORIA
        public int Id
        {
            get { return id; }
            set { id = value; }
        }             

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }        

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
        #endregion

        //CONSTRUCTOR
        #region CONSTRUCTOR
        public Categoria(int id, string nombre, string descripcion)
        {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;         

        }
        #endregion

        //TOSTRING
        #region TOSTRING
        public override string ToString()
        {
            string respuesta = "";
            respuesta += "ID Categoría: " + this.Id +  "\n" ; 
            respuesta += "Nombre de categoría: " + this.Nombre + "\n" ; 
            respuesta += "Descripción de Categoría: " + this.Descripcion + "\n" ; 
            return respuesta;

        }
        #endregion
    }

   

}