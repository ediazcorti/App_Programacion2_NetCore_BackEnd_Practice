﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Sistema
    {
        //INICIALIZAMOS EL VALOR POR DEFECTO DEL AFORO E INICIALIZAMOS LAS LISTAS QUE VA A USAR EL SISTEMA
        #region INICIALIZACIÓN DE LISTAS Y ATRIBUTOS 

        //Inicializamos AforoMax en 100% para tener un valor por defecto que mostrarle al usuario al iniciar la Aplicación.
        private static int aforoMax = 100;        

        private static string[] edadesPermitidas = { "P", "C13", "C16", "C18" };
           
        private List<Lugar> lugares = new List<Lugar>();

        private static List<Actividad> cartelera = new List<Actividad>();

        private List<Usuario> usuariosRegistrados = new List<Usuario>();

        private List<Compra> comprasRegistradas = new List<Compra>();

        private List<Categoria> categorias = new List<Categoria>();

        private static Sistema instancia;
        #endregion

        // COLOCAMOS LOS RESPECTIVO "GET" A ESTAS LISTAS:
        #region GETTERS 
        public static Sistema Instancia
        {
            get
            {
                if(instancia == null)
                {
                    instancia = new Sistema();
                }
                return instancia;
            }
        }
        public static int AforoMax
        {
            get { return aforoMax; }
            set { aforoMax = value; }
        }

        public List<Categoria> Categorias
        {
            get { return categorias; }
        }

        public List<Compra> ComprasRegistradas
        {
            get { return comprasRegistradas; }
        }

        public List<Usuario> UsuariosRegistrados
        {
            get { return usuariosRegistrados; }
        }

        public List<Actividad> Cartelera
        {
            get { return cartelera; }
            set { cartelera = value;  }
        }
        public List<Lugar> Lugares
        {
            get { return lugares; }
        }
       

        #endregion

        // EJECUTAMOS TODOS LOS METODOS DE PRECARGA NECESARIOS
        #region EJECUCIÓN DE MÉTODOS DE PRECARGA
        private Sistema()
        {
            
            precargarUsuarios();
            precargaCategorias();
            precargarLugares();
            precargarActividades();
            precargarCompras();
            

        
    }
        #endregion



        // ACÁ VAN TODOS LOS MÉTODOS DE PRECARGA CON SUS RESPECTIVOS LISTAS Y OBJETOS, 
        // INCLUYEN SUS VALIDADORES ESPECÍFICOS
        #region MÉTODOS DE PRECARGAS
        public void precargarUsuarios()
        {
            Usuario nuevoUsuario;

            nuevoUsuario = new Usuario("Emanuel", "Medina", "ediazcorti@gmail.com", new DateTime(1997, 06, 16), "ediaz", "ema123", "Cliente");
            AgregarUsuario(nuevoUsuario);

            nuevoUsuario = new Usuario("Marcos", "Medina", "markmed@gmail.com", new DateTime(1998, 08, 04), "markmed", "mark123", "Cliente");
            AgregarUsuario(nuevoUsuario);

            nuevoUsuario = new Usuario("Florencia", "Hernandez", "flopyHern@gmail.com", new DateTime(1995, 04, 04), "flopyhern", "flopy123", "Operador");
            AgregarUsuario(nuevoUsuario);

            nuevoUsuario = new Usuario("Roberto", "Rodriguez", "robertRod@gmail.com", new DateTime(2000, 09, 04), "robertRod", "robert123", "Operador");
            AgregarUsuario(nuevoUsuario);
        }
        public Usuario BuscarUsuarioId(int idParam)
        {
            int i = 0;
            Usuario usuarioResult = null;
            while (usuarioResult == null && i < usuariosRegistrados.Count)
            {
                if (usuariosRegistrados[i].Id == idParam)
                {
                    usuarioResult = usuariosRegistrados[i];
                }
                i++;
            }
            return usuarioResult;
        }
        public Usuario BuscarUsuarioNombre(string nombreUsuarioParam)
        {
            int i = 0;
            Usuario usuarioResult = null;
            while (usuarioResult == null && i < usuariosRegistrados.Count)
            {
                if (usuariosRegistrados[i].NombreUsuario == nombreUsuarioParam)
                {
                    usuarioResult = usuariosRegistrados[i];
                }
                i++;
            }
            return usuarioResult;
        }

        public bool AgregarUsuario(Usuario nuevoUsuario)
        {
            bool fueAgregado = false;
            if (BuscarUsuarioId(nuevoUsuario.Id) == null)
            {
                usuariosRegistrados.Add(nuevoUsuario);
                fueAgregado = true;
            }
            return fueAgregado;
        }

        public void precargaCategorias()
        {
            Categoria unaCategoria;

            unaCategoria = new Categoria(1, "Cine", "Mira tus películas favoritas en la pantalla grande.");
            AgregarCategoria(unaCategoria);

            unaCategoria = new Categoria(2, "Teatro", "Ven a ver tus obras favoritas con artistas de todo el mundo.");
            AgregarCategoria(unaCategoria);

            unaCategoria = new Categoria(3, "Concierto", "Vive una experiencia irrepetible con tus músicos favoritos en el mejor lugar.");
            AgregarCategoria(unaCategoria);

            unaCategoria = new Categoria(4, "Otros", "Disfruta de otros tipos de eventos que no coinciden con las categorías anteriores, como concursos, festivales o eventos.");
            AgregarCategoria(unaCategoria);

        }
        public Categoria BuscarCategoria(int idParam)
        {
            int i = 0;
            Categoria categoriaResult = null;
            while (categoriaResult == null && i < categorias.Count)
            {
                if (categorias[i].Id == idParam)
                {
                    categoriaResult = categorias[i];
                }
                i++;
            }
            return categoriaResult;
        }

        public bool AgregarCategoria(Categoria nuevaCategoria)
        {
            bool fueAgregado = false;
            if (BuscarCategoria(nuevaCategoria.Id) == null)
            {
                categorias.Add(nuevaCategoria);
                fueAgregado = true;
            }
            return fueAgregado;
        }

        public void precargarLugares()
        {
            Lugar nuevoLugar;

            nuevoLugar = new Abierto( "Campeon del Siglo", 7140);
            AgregarLugar(nuevoLugar);

            nuevoLugar = new Abierto( "Parque Central", 7140);
            AgregarLugar(nuevoLugar);

            nuevoLugar = new Cerrado( "Teatro Solis", 2804, true, 500000);
            AgregarLugar(nuevoLugar);            

            nuevoLugar = new Cerrado( "MovieCenter Portones", 6000, false, 30000);
            AgregarLugar(nuevoLugar);

            nuevoLugar = new Cerrado( "Lotus: Salon de Eventos", 4000, true, 100000);
            AgregarLugar(nuevoLugar);

        }
        public Lugar BuscarLugares(int idParam)
        {
            int i = 0;
            Lugar lugarResult = null;
            while (lugarResult == null && i < lugares.Count)
            {
                if (lugares[i].Id == idParam)
                {
                    lugarResult = lugares[i];
                }
                i++;
            }
            return lugarResult;
        }

        public bool AgregarLugar(Lugar nuevoLugar)
        {
            bool fueAgregado = false;
            if (BuscarLugares(nuevoLugar.Id) == null)
            {
                lugares.Add(nuevoLugar);
                fueAgregado = true;
            }
            return fueAgregado;
        }

        public void precargarActividades()
        {
            //PONER COMO COMENTARIO TODO LO QUE ESTÁ EN ESTE BLOQUE SI SE QUIERE TESTEAR QUÉ PASA SI NO HAY ACTIVIDADES:

            Actividad nuevaActividad;
            //ACTIVIDADES EN LUGARES ABIERTOS: (LUGAR = 0 O LUGAR = 1) 
            #region 5 ACTIVIDADES DE LUGARES ABIERTOS
            nuevaActividad = new Actividad("Partido Clásico: Peñarol-Nacional", categorias[3], new DateTime(2021, 12, 20), lugares[1], edadesPermitidas[0], 800, 66);
            AgregarActividad(nuevaActividad); 

            nuevaActividad = new Actividad("Partido Peñarol - Wanderers ", categorias[3], new DateTime(2021, 12, 20), lugares[0], edadesPermitidas[0], 200, 20);
            AgregarActividad(nuevaActividad);
            
            nuevaActividad = new Actividad("Concierto de NTVG", categorias[2], new DateTime(2021, 12, 1), lugares[1], edadesPermitidas[1], 2000, 200);
            AgregarActividad(nuevaActividad);
            
            nuevaActividad = new Actividad("Cirque du Solei: al Aire Libre", categorias[3], new DateTime(2021, 10, 15), lugares[0], edadesPermitidas[0], 500, 85);
            AgregarActividad(nuevaActividad);
                        
            nuevaActividad = new Actividad("Presentación de James Rodrigues en Peñarol", categorias[3], new DateTime (2021, 11, 01) ,lugares[0], edadesPermitidas[2], 9000, 4572);
            AgregarActividad(nuevaActividad);

            #endregion

            // ACÁ VAN LAS 5 ACTIVIDADES EN LUGARES CERRADOS
            #region 5 ACTIVIDADES DE LUGARES CERRADOS
            nuevaActividad = new Actividad("Opera Monteverdi", categorias[1], new DateTime(2021, 11, 20), lugares[1], edadesPermitidas[3], 1600, 19);
            AgregarActividad(nuevaActividad);

            nuevaActividad = new Actividad("Eminem Concierto", categorias[2], new DateTime(2021, 11, 20), lugares[3], edadesPermitidas[3], 1600, 19);
            AgregarActividad(nuevaActividad);

            nuevaActividad = new Actividad("Pelicula James Bond 007", categorias[0], new DateTime(2021, 10, 20), lugares[3], edadesPermitidas[2], 600, 12);
            AgregarActividad(nuevaActividad);

            nuevaActividad = new Actividad("Basketball Lakers Show", categorias[3], new DateTime(2021, 10, 15), lugares[2], edadesPermitidas[0], 1500, 320);
            AgregarActividad(nuevaActividad);

            nuevaActividad = new Actividad("Charla Ted: Steve Trabajos", categorias[3], new DateTime(2021, 12, 1), lugares[4], edadesPermitidas[1], 720, 200);
            AgregarActividad(nuevaActividad);
            #endregion

        }
        public Actividad BuscarActividad(int idParam)
        {
            int i = 0;
            Actividad actividadResult = null;
            while (actividadResult == null && i < cartelera.Count)
            {
                try { 
                    if (cartelera[i].Id == idParam)
                {
                    actividadResult = cartelera[i];
                }
                }
                catch { }
                i++;
            }
            return actividadResult;
        }

        public bool AgregarActividad(Actividad nuevaActividad)
        {
            bool fueAgregado = false;
            if (BuscarActividad(nuevaActividad.Id) == null)
            {
                cartelera.Add(nuevaActividad);
                fueAgregado = true;
            }
            return fueAgregado;
        }

        private void precargarCompras()
        {
            Compra nuevaCompra;
            //ESTA PRECARGA LE ASIGNAMOS UN TRYCATCH, PORQUE EN CASOS DE TESTEO EN LOS QUE NO TENGAS ACTIVIDADES Y LA CARTELERA ESTE VACIA,
            //AL INTENTAR CREAR UNA NUEVA COMPRA,
            //SE VA A CRASHEAR POR TENER UNA LISTA VACÍA AL QUERER CREAR ACTIVIDADES EN INDICES DE LISTA QUE NO EXISTEN.
            try {  
            nuevaCompra = new Compra(cartelera[1], 1, usuariosRegistrados[0], new DateTime(2021, 10, 2), cartelera[1].calcularPrecio());
            RegistrarCompra(nuevaCompra);

            nuevaCompra = new Compra(cartelera[2], 6, usuariosRegistrados[1], new DateTime(2021, 10, 6), cartelera[2].calcularPrecio());
            RegistrarCompra(nuevaCompra);
            }
            catch
            {

            }

        }
        public Compra BuscarCompra(int idParam)
        {
            int i = 0;
            Compra compraResult = null;
            while (compraResult == null && i < comprasRegistradas.Count)
            {
                if (comprasRegistradas[i].Id == idParam)
                {
                    compraResult = comprasRegistradas[i];
                }
                i++;
            }
            return compraResult;
        }

        public bool RegistrarCompra(Compra nuevaCompra)
        {
            bool fueAgregado = false;
            if (BuscarCompra(nuevaCompra.Id) == null)
            {
                comprasRegistradas.Add(nuevaCompra);
                fueAgregado = true;
            }
            return fueAgregado;
        }

        #endregion

        public Actividad getActividad(int idSearch)
        {
            int i = 0;
            while (i < Cartelera.Count && idSearch != Cartelera[i].Id)
            {
                i++;
            }
            if (i < Cartelera.Count)
            {
                return Cartelera[i];
            }
            else
            {
                return null;
            }
        }

        

    }
}
