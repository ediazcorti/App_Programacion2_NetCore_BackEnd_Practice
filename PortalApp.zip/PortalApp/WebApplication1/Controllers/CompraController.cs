﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ObligatorioP2;
using Microsoft.AspNetCore.Http;

namespace WebApplication1.Controllers
{
    public class CompraController : Controller
    {
        Sistema unS = Sistema.Instancia;
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult VerCompras()
        {
            Usuario usuarioLoggeado = unS.BuscarUsuarioNombre(HttpContext.Session.GetString("username"));

            if (usuarioLoggeado != null)
            {
                List<Compra> comprasDelUsuario = new List<Compra>();
                foreach (Compra compra in unS.ComprasRegistradas)
                {
                    if (compra.UsuarioComprador.Id == usuarioLoggeado.Id)
                    {
                        comprasDelUsuario.Add(compra);
                    }
                }
                ViewBag.comprasDelUsuario = comprasDelUsuario;
                return View();
            }
            ViewBag.Mensaje = "Primero loggeate!";
            return Redirect("/usuario/login/");
        }
        
        public IActionResult Cancelar(int id)
        {
            int compraIdParsed = Convert.ToInt32(id);
            Usuario usuarioLoggeado = unS.BuscarUsuarioNombre(HttpContext.Session.GetString("username"));
            Compra compraACancelar = unS.BuscarCompra(compraIdParsed);

            if (usuarioLoggeado != null)
            {
                if (compraACancelar.cancelarComprar())
                {
                    TempData["mensaje"] = "Su compra ha sido cancelada!";
                    TempData["tipoMensaje"] = "success";
                }
                else
                {
                    TempData["mensaje"] = "Su compra NO se ha podido cancelar. Ya pasaron 24hs";
                    TempData["tipoMensaje"] = "error";
                }
                List<Compra> comprasDelUsuario = new List<Compra>();
                foreach (Compra compra in unS.ComprasRegistradas)
                {
                    if (compra.UsuarioComprador.Id == usuarioLoggeado.Id)
                    {
                        comprasDelUsuario.Add(compra);
                    }
                }
                ViewBag.comprasDelUsuario = comprasDelUsuario;
                return Redirect("/compra/verCompras");
            }
            ViewBag.Mensaje = "Primero loggeate!";
            return Redirect("/usuario/login/");
        }

        [HttpPost]
        public IActionResult Registrar(string idActividad, string cantidadEntradas)
        {
            Usuario usuarioLoggeado = unS.BuscarUsuarioNombre(HttpContext.Session.GetString("username"));
            int idActividadPars = Convert.ToInt32(idActividad);
            Actividad actividadEncontrada = unS.BuscarActividad(idActividadPars);

            if (usuarioLoggeado != null && actividadEncontrada != null)
            {
                int cantidadEntradasParseada = Convert.ToInt32(cantidadEntradas);
                Compra nuevaCompra = new Compra(actividadEncontrada, cantidadEntradasParseada, usuarioLoggeado, DateTime.Now, actividadEncontrada.calcularPrecio());
                if (unS.RegistrarCompra(nuevaCompra))
                {
                    List<Compra> comprasDelUsuario = new List<Compra>();
                    foreach(Compra compra in unS.ComprasRegistradas)
                    {
                        if(compra.UsuarioComprador.Id == usuarioLoggeado.Id)
                        {
                            comprasDelUsuario.Add(compra);
                        }
                    }
                    ViewBag.comprasDelUsuario = comprasDelUsuario;
                    return View(nuevaCompra);
                }
            }
            ViewBag.Mensaje = "Algo salió mal. Consulte con algun administrador.";
            return Redirect("/actividad/ver/" + idActividad);
        }

        public IActionResult Ventas(string fechaInicial, string fechaFinal)
        {

            List<Compra> ventas = unS.ComprasRegistradas;
            
                List<Compra> ventasFiltradas = new List<Compra>();
                decimal totalVentas = 0;
                foreach (Compra compra in ventas)
                {
                    if(fechaInicial != null && fechaFinal != null)
                    {
                        if (Convert.ToDateTime(fechaInicial) <= compra.DateTimeCompra && compra.DateTimeCompra <= Convert.ToDateTime(fechaFinal))
                        {
                            ventasFiltradas.Add(compra);
                            totalVentas += compra.PrecioFinal;
                        }
                    }
                    else
                    {
                        ventasFiltradas.Add(compra);
                        totalVentas += compra.PrecioFinal;

                    }
                }
                ViewBag.totalVentas = totalVentas;
                ViewBag.ventas = ventasFiltradas;
                return View();
        }
    }
}
