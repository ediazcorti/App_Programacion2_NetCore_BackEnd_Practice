﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public abstract class Lugar
    {
        private int id;
        private string nombre;
        private int dimensiones; // en m2
        private static int ultimoId = 0;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public int Dimensiones
        {
            get { return dimensiones; }
            set { dimensiones = value; }
        }

        public Lugar(string nombreParam, int dimensionesParam)
        {
            this.Id = ++ultimoId;
            nombre = nombreParam;
            dimensiones = dimensionesParam;
        }

        public abstract string TipoLugar();

        public abstract decimal calcularPrecio(decimal precioBase);
        public override string ToString(){
            string response = "";

            response += "ID: "+ id + "\n";
            response += "Nombre: "+ nombre + "\n";
            response += "Dimensiones: "+ dimensiones + "\n";
            response += "Tipo de lugar: "+ TipoLugar() + "\n";

            return response;
        }

    }
}
