﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Actividad
    {
        private int id;
        private string nombre;
        private DateTime dateTimeActividad;
        private Lugar lugarActividad;
        private string minEdad;
        private decimal precioBase;
        private int likes;
        private Categoria categoria;
        private static int ultimoId = 0;

        public Categoria Categoria
        {
            get { return categoria; }
            set { categoria = value; }
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public DateTime DateTimeActividad
        {
            get { return dateTimeActividad; }
            set { dateTimeActividad = value; }
        }

        public Lugar LugarActividad
        {
            get { return lugarActividad; }
            set { lugarActividad = value; }
        }

        public string MinEdad
        {
            get { return minEdad; }
            set { minEdad = value; }
        }

        public decimal PrecioBase
        {
            get { return precioBase; }
            set { precioBase = value; }
        }

        public int Likes
        {
            get { return likes; }
            set { likes = value; }
        }
              

        public int UltimoId
        {
            get { return ultimoId; }
            set { ultimoId = value; }
        }


        public decimal calcularPrecio()
        {
            return lugarActividad.calcularPrecio(precioBase);
        }

        public Actividad(string nombreParam, Categoria categoriaParam, DateTime dateTimeActividadParam, Lugar lugarActividadParam, string minEdadParam, int precioBaseParam, int likesParam)
        {
            this.id = ++ultimoId;
            nombre = nombreParam;
            categoria = categoriaParam;
            dateTimeActividad = dateTimeActividadParam;
            lugarActividad = lugarActividadParam;
            minEdad = minEdadParam;
            precioBase = precioBaseParam;
            likes = likesParam;
        }

        public bool darLike()
        { // CHECKs
            Likes++;
            return true;
        }

        public override string ToString()
        {
            string respuesta = "";
            respuesta += "ID Actividad: " + this.Id + "\n";
            respuesta += "Nombre de Actividad: " + this.Nombre + "\n";
            respuesta += "Categoría de actividad: " + this.Categoria + "\n";
            respuesta += "Fecha de Actividad: " + this.DateTimeActividad + "\n";
            respuesta += "Lugar: " + this.LugarActividad + "\n";
            respuesta += "Categoría de edad: " + this.MinEdad + "\n";
            respuesta += "Precio Base (Entrada) " + this.PrecioBase + "\n";
            respuesta += "Likes: " + this.Likes + "\n";
            return respuesta;
        }

     


    }
}
