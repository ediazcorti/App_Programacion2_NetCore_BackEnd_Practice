﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Compra
    {

        #region ATRIBUTOS 
        private int id;
        private int cantidadEntradas;
        private DateTime dateTimeCompra;
        private bool estaActiva;
        private Actividad actividad;
        private Usuario usuarioComprador;
        private static int ultimoId = 0;
        private decimal precioFinal;


        #endregion


        #region PROPIEDADES
        public decimal PrecioFinal{
            get { return precioFinal; }
        }
        public int Id
        {
            get { return id; }
        }
        public int CantidadEntradas
        {
            get { return cantidadEntradas; }
            set { cantidadEntradas = value; }
        }

        public DateTime DateTimeCompra
        {
            get { return dateTimeCompra; }
            set { dateTimeCompra = value; }
        }

        public bool EstaActiva
        {
            get { return estaActiva; }
            set { estaActiva = value; }
        }

        public Actividad Actividad
        {
            get { return actividad; }
            set { actividad = value; }
        }

        public Usuario UsuarioComprador
        {
            get { return usuarioComprador; }
            set { usuarioComprador = value; }
        }


        #endregion



        #region METODOS
        public Compra() { }
        public Compra(Actividad actividad, int cantidadEntradasParam, Usuario usuarioComprador, DateTime dateTimeCompra, decimal precioActividad) 
        {
            this.id = ++ultimoId;
            this.actividad = actividad;
            this.usuarioComprador = usuarioComprador;
            cantidadEntradas = cantidadEntradasParam;
            this.dateTimeCompra = dateTimeCompra;
            this.estaActiva = true;
            precioFinal = calcularPrecioFinal(precioActividad, cantidadEntradasParam);


        }

        //ESTE METODO QUEDA SIN TERMINAR EN ESTA ETAPA POR LA LETRA DEL DOCUMENTO
        public decimal calcularPrecioFinal (decimal precioEntrada, int cantidadEntradasParam)
        {
            decimal precioFinal = 0;
            decimal precioCompra = (precioEntrada * cantidadEntradasParam);
            if (cantidadEntradasParam > 5)
            {
                precioFinal = ((decimal)((double)(precioCompra) * 0.95));
            }
            else
            {
                precioFinal = precioCompra;
            }
            return precioFinal; 
        }
       
        public bool cancelarComprar()
        {
            bool resultadoCancelacion = false;

            if (DateTime.Now < dateTimeCompra.AddHours(24))
            {
                EstaActiva = false;
                resultadoCancelacion = true;
            }
            return resultadoCancelacion;
        }


        public override string ToString()
        {
            string respuesta = "";
            respuesta += "ID de Compra: " + this.Id + "\n"; 
            respuesta += "Actividad: " + this.Actividad + "\n"; 
            respuesta += "Usuario Comprador: " + this.usuarioComprador + "\n"; 
            respuesta += "Cantidad de Entradas Compradas:" + this.CantidadEntradas + "\n"; 
            respuesta += "Fecha de compra: " + this.DateTimeCompra + "\n"; 
            respuesta += "Estado de Compra (Activa o Cancelada): " + (this.estaActiva ? "Activa" : "Cancelada") + "\n"; 
            return respuesta;
        }




        #endregion


    }
}
