﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Cerrado : Lugar
    {
        private bool accesibilidad;
        private int valorMantenimiento;        

        public bool Accesibilidad
        {
            get { return accesibilidad; }
            set { accesibilidad = value; }
        }
        public int ValorMantenimiento
        {
            get { return valorMantenimiento; }
            set { valorMantenimiento = value; }
        }

        public Cerrado(string nombreParam, int dimensionesParam, bool accesibilidadParam, int valorMantenimientoParam) : base( nombreParam, dimensionesParam)
        {
            
            accesibilidad = accesibilidadParam;
            valorMantenimiento = valorMantenimientoParam;
        }
        public override decimal calcularPrecio(decimal precioBase) 
        {
            decimal precioFinal = precioBase;
            if (Sistema.AforoMax < 50)
            {
                precioFinal *= (decimal)1.3;
            }
            else if (Sistema.AforoMax > 50 && Sistema.AforoMax < 70)
            {
                precioFinal *= (decimal)1.15;
            }
            return precioFinal;
        }
        public override string TipoLugar()
        {
            return "Cerrado";
        }

        public override string ToString()
        {
            string response = base.ToString();
            response += "Accesibilidad: " + (accesibilidad?"Sí":"No") + "\n";
            response += "Valor Mantenimiento: " + valorMantenimiento + "\n";

            return response;
        }

        //private static int aforoMax = 100;
        //public int AforoMax
        //{
        //    get { return aforoMax; }
        //    set { aforoMax = value; }
        //}

        //// metodo encargado de cambiar el porcentaje de aforo:
        //public static void cambiarAforoMax(int valueParam)
        //{
        //    aforoMax = valueParam;
        //    Console.WriteLine("\n" + "Se ha cambiado aforo máximo. Ahora el aforo máximo es de " + aforoMax + " personas .");
        //}

    }
}
