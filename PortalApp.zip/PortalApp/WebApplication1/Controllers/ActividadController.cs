﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ObligatorioP2;
using Microsoft.AspNetCore.Http;

namespace WebApplication1.Controllers
{
    public class ActividadController : Controller
    {
        Sistema unS = Sistema.Instancia;

        public IActionResult Index()
        {
            ViewBag.role = "noCliente";
            ViewBag.ActividadesList = unS.Cartelera;
            return View();
        }

        public IActionResult darLike(int id)
        {
            if(HttpContext.Session.GetString("username") != null)
            {
                Actividad actividadEspifica = unS.BuscarActividad(id);
                if (actividadEspifica != null)
                {
                    actividadEspifica.darLike();
                    TempData["mensaje"] = "Diste like a: "+actividadEspifica.Nombre;
                    TempData["tipoMensaje"] = "success";
                    return RedirectToAction("Index");
                }
                else
                {
                    TempData["mensaje"] = "No existe esa actividad";
                    TempData["tipoMensaje"] = "error";
                    return RedirectToAction("Index");
                }

            }
            ViewBag.Mensaje = "Primero loggeate!";
            return Redirect("/usuario/login/");

        }

        public IActionResult Ver(int id)
        {
            Actividad currentActividad = unS.BuscarActividad(id);
            if(currentActividad == null)
            {
                return RedirectToAction("Index");
            }
            return View(currentActividad);
        }
    }
}
