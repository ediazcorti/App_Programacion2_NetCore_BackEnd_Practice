﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Usuario
    {

        // ATRIBUTOS
        #region ATRIBUTOS USUARIO
        private int id;
        private string nombre;
        private string apellido;
        private string email;
        private string password;
        private DateTime fechaNac;
        private string nombreUsuario;
        private static int ultimoId = 0;
        private string rol;
        #endregion

        //MÉTODOS
        #region METODOS USUARIO

        public int Id
        {
            get { return id; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }                   

        public DateTime FechaNac
        {
            get { return fechaNac; }
            set { fechaNac = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string NombreUsuario
        {
            get { return nombreUsuario; }
            set { nombreUsuario = value; }
        }
        public string Rol
        {
            get { return rol; }
            set { rol = value; }
        }

        #endregion

        //CONSTRUCTOR
        #region CONSTRUCTOR USUARIO
        public Usuario()
        {
        }
        public Usuario (string nombreParam, string apellidoParam, string emailParam, DateTime fechaNacParam, string nombreUsuarioParam, string passwordParam, string rolParam)
        {
            id = ++ultimoId;
            nombre = nombreParam;
            apellido = apellidoParam;
            email = emailParam;
            fechaNac = fechaNacParam;
            nombreUsuario = nombreUsuarioParam;
            password = passwordParam;
            rol = rolParam;
        }

        #endregion

        //TOSTRING
        #region TOSTRING

        public override string ToString()
        {
            string respuesta = "";
            respuesta += "ID DE USUARIO: " + this.Id + "\n";
            respuesta += "Nombre: " + this.Nombre + "\n" ;
            respuesta += "Apellido: " + this.Apellido + "\n";
            respuesta += "E-mail: " + this.email + "\n";
            respuesta += "Fecha de Nacimiento: " + this.fechaNac.ToShortDateString() + "\n"; 
            return respuesta;

        }
        #endregion

    }
}
