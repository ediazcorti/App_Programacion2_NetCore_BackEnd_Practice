﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObligatorioP2
{
    public class Abierto : Lugar
    {
        private static int precioButaca = 400;
        

        public int PrecioButaca
        {
            get { return precioButaca; }
            set { precioButaca = value; }
        }

        public Abierto( string nombreParam, int dimensionesParam) :base(nombreParam,dimensionesParam)
        {
           
        }

        public override string TipoLugar()
        {
            return "Abierto";
        }

        public override string ToString()
        {
            string response = base.ToString();

            response += "Precio Butaca: " + precioButaca + "\n";
            //Sistema.AforoMax

            return response;
        }
        public override decimal calcularPrecio(decimal precioBase) /*Actividad y no precioBase para mejor escalabilidad*/
        {

            decimal precioFinal = precioBase;
            if (Dimensiones > 1000 /*m2*/)
            {
                precioFinal *= (decimal)1.1;
            }

            return precioFinal;
        }
        public static void cambiarPrecioButaca(int valueParam)
        {
            precioButaca = valueParam;
            Console.WriteLine("\n" + "Se ha cambiado el precio para las butacas. Ahora el nuevo precio es de $" + precioButaca + " .");
        }
        

    }
}
