﻿using System;
using System.Collections.Generic;

namespace ObligatorioP2
{
    public class Program
    {
        public static Sistema unS = Sistema.Instancia;

        static void Main(string[] args)
        {
            PedirNumero();
            Console.ReadKey();
           
        }

        public static void PedirNumero()
        {
            string opcion = "";
            do
            {
                Titulo("Menu");
                Console.WriteLine(ArmoMenu());
                opcion = (Console.ReadLine());
                switch (opcion)
                {
                    case "1":
                       // HACEMOS UN TRYCATCH QUE SE FIJE SI HAY ITEMS EN LA LISTA.
                       // ES NECESARIO UN TRYCATCH PORQUE SI SOLO PONEMOS LA CONDICION DEL .COUNT Y ENCUENTRA UNA LISTA VACÍA, EL PROGRAMA PUEED CRASHEAR POR UNA EXCEPTION
                       // EL CATCH PREVIENE EL CRASH, YA QUE SI HAY UNA EXCEPCION (ES DECIR, LA LISTA ESTÁ VACÍA) SOLO LE AVISA AL USUARIO QUE LA LISTA ESTA VACÍA
                        try
                        {
                            int cantidadActividades = unS.Cartelera.Count;
                            if (unS.Cartelera.Count > 0 ) { MostrarCartelera();
                                Console.WriteLine("Digite cualquier tecla para continuar");
                                Console.ReadKey();
                                break;
                            }
                            else {
                                // Si no hay actividades, le avisamos al usuario
                                Console.WriteLine("No hay actividades disponibles actualmente. Intente otro día.\n Digite cualquier tecla para continuar.");
                                Console.ReadKey();
                            }
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("Este texto no será mostrado en consola.");
                            //No pusimos el texto de Aviso en esta parte porque por alguna razón antes ejecutaba lo de esta parte, pero ahora no, nomás fixea la exception.
                        }                        
                        break;
                    case "2":
                        //Pedimos al usuario que ingrese el nuevo aforo y TryParseamos su texto para ver si es número.
                        Console.WriteLine("El aforo máximo actual de los lugares cerrados es de un " + Sistema.AforoMax + " % .");                        
                        Console.WriteLine("Escriba el nuevo aforo máximo a designar");
                        int aforoEdit = 0;
                        aforoEdit = PedirYParsearNumero(aforoEdit);
                        //unS.AforoMax = aforoEdit;
                        //Apenas ponga un número válido, se accede a modificar el valor y se avisa al usuario.
                        cambiarAforoMax(aforoEdit);                        
                        Console.WriteLine("\nEl aforo máximo ha sido cambiado a " + aforoEdit);
                        //Dejamos que el usuario vea el resultado exitoso y continúe con el menú.
                        Console.WriteLine("Digite cualquier tecla para continuar");
                        Console.ReadKey();
                        break;
                    case "3":
                        // SE LE PIDE AL USUARIO QUE ELIJA UN PRECIO PARA LAS BUTACAS
                        Console.WriteLine("Elija un nuevo precio para las butacas");

                        //SE CREA LA VARIABLE PARA GUARDAR EL VALOR NUEVO A LA BUTACA 
                        int butacaEdit = 0;
                        // HACEMOS UN TRYPARSE DE LO QUE ESCRIBA EL USUARIO, SI NO ES UN NUMERO SE PIDE DIGITE DE NUEVO.
                        butacaEdit = PedirYParsearNumero(butacaEdit);                      
                        // LUEGO DE QUE YA SE PUDO DIGITAR UN NUMERO, ASIGNAMOS EL VALOR DIGITADO A LA FUNCION DE CAMBIAR PRECIO DE BUTACA PARA HACER EL CAMBIO
                        Abierto.cambiarPrecioButaca(butacaEdit);
                        //Dejamos que el usuario vea el resultado exitoso y continúe con el menú.
                        Console.WriteLine("Digite cualquier tecla para continuar");
                        Console.ReadKey();
                        break;
                    case "4":
                        // ELEGIR CATEGORIA CON UN NUMERO SEGÚN EL MENÚ GUÍA
                        Console.WriteLine("Elija una categoría para mostrar: \n" + " 1 - Cine \n 2 - Teatro \n 3 - Concierto \n 4 - Otros");
                        int categoriaInput = 0;
                        categoriaInput = PedirYParsearNumero(categoriaInput);                        
                        Console.WriteLine("Digite una fecha inicial");

                        //INGRESAR FECHA INICIAL, ENTRAMOS A FUNCION QUE INTENTA PARSEAR LO ESCRITO A FECHA, SI NO LO LOGRA, VUELVE A PEDIR REINGRESO DE FECHA

                        Console.WriteLine("\n" + "Ingrese fecha INICIAL en formato: 'DD, MM, AAAA' : ");
                        DateTime fechaInicio = new DateTime();                        
                        fechaInicio = IngresarFecha(fechaInicio);                        

                        //IDEM FECHA INICIAL, SI NO SE PARSEA, SE PIDE DE NUEVO

                        Console.WriteLine("\n" + "Ingrese fecha FINAL en formato: 'DD, MM, AAAA' ");
                        DateTime fechaFinal = new DateTime();
                        fechaFinal = IngresarFecha(fechaFinal);                        

                        mostrarActividadesCategoria(categoriaInput, fechaInicio, fechaFinal);
                        //Dejamos que el usuario vea el resultado exitoso y continúe con el menú.
                        Console.WriteLine();
                        Console.WriteLine("Digite cualquier tecla para continuar");
                        Console.ReadKey();
                        break;
                    case "5":
                        mostrarActividadesATP();
                        //Dejamos que el usuario vea el resultado exitoso y continúe con el menú.
                        Console.WriteLine("Digite cualquier tecla para continuar");
                        Console.ReadKey();
                        break;
                    case "0":
                        Console.WriteLine("\n¡Hasta Pronto! \nDigite cualquier tecla para cerrar esta aplicación.");
                        break;
                    default:
                        // SI NO SE PUSO NINGUNA DE LAS 5 OPCIONES DE NUMEROS QUE PIDE ESTA FUNCIÓN, SE LE AVISA AL USUARIO QUE ESCRIBA UN NUMERO DEL 1 AL 5.
                        Console.WriteLine("Error: Porfavor, digite un número válido entre 1 y 5 o digite 0 para Salir. \n Presione cualquier tecla para recargar el menú");
                        Console.ReadKey();
                        break;
                }

            } while (opcion != "0");

        }

        public static int PedirYParsearNumero(int numero)
        {
            int formatoNumero;
            if (int.TryParse(Console.ReadLine(), out formatoNumero)) 
            {
                numero = formatoNumero;
                Console.WriteLine("Numero ingresado con éxito.\nPresione cualquier tecla para continuar");
                Console.ReadKey();
                return numero;
            }
            else
            {
                Console.WriteLine("No ha ingresado un número válido. Porfavor intente de nuevo ingresando un número");
                numero = PedirYParsearNumero(numero);
            }
            return numero;
                        }


        public static DateTime IngresarFecha(DateTime fecha) {
            DateTime formatoFecha;            
            if (DateTime.TryParse(Console.ReadLine(), out formatoFecha))
                        {
                            fecha = formatoFecha;
                            Console.WriteLine("Fecha ingresada:" + fecha.ToShortDateString());
                        return fecha; 
                        }
                        else {
                            Console.WriteLine("No ha ingresado una fecha, intente nuevamente");
                fecha = IngresarFecha(fecha);
}
            return fecha;
        }



        public static void MostrarCartelera()
        {
            string respuesta = "";
            respuesta += "_____________________ LISTA DE ACTIVIDADES _____________________\n\n";
            foreach (Actividad actividad in unS.Cartelera)
            {
                respuesta += "\n::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
                respuesta += "--------------------------- ACTIVIDAD " + actividad.Id + " ----------------------------\n";
                respuesta += "\n::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
                respuesta += "ID Actividad: " + actividad.Id + "\n";
                respuesta += "Nombre de Actividad: " + actividad.Nombre + "\n";
                respuesta += "Categoria: " + actividad.Categoria.Nombre + "\n";
                respuesta += "Fecha de Actividad: " + actividad.DateTimeActividad + "\n";
                respuesta += "Lugar: " + actividad.LugarActividad + "\n";
                respuesta += "Categoría de edad: " + actividad.MinEdad + "\n";
                respuesta += "Likes: " + actividad.Likes + "\n";
               
                
            }
            Console.WriteLine(respuesta);
        }



        public static void cambiarAforoMax(int valParam)
        {
           
            try 
            {
                Sistema.AforoMax = valParam;
                return;
                
                
            }
            catch
            {
                Console.WriteLine("No ha ingresado un número válido. Porfavor intente de nuevo ingresando un número");
                cambiarAforoMax(valParam = PedirYParsearNumero(valParam)); 
            }
          

        }


        public static void mostrarActividadesCategoria(int categoriaFiltro, DateTime fecha1, DateTime fecha2)
        {
            string numeroCategoria = categoriaFiltro.ToString();
            string nombreCategoria = "";
            string descripcion = "";
            
            switch (numeroCategoria) {
                case "1":
                    nombreCategoria = "Cine";
                    descripcion = unS.Categorias[0].Descripcion;
                    break;
                case "2":
                    nombreCategoria = "Teatro";
                    descripcion = unS.Categorias[1].Descripcion;
                    break;
                case "3":
                    nombreCategoria = "Concierto";
                    descripcion = unS.Categorias[2].Descripcion;
                    break;
                case "4":
                    nombreCategoria = "Otros";
                    descripcion = unS.Categorias[3].Descripcion;
                    break;
            }
            string respuesta = "";
            // Le damos al usuario la info sobre la categoría elegida en consola:
            respuesta += "\n______________________________________________________\n";
            respuesta += "\n" + "LISTA DE ACTIVIDADES DE LA " + "CATEGORÍA " + nombreCategoria.ToUpper() ;            
            respuesta += "\n\n" + "DESCRIPCIÓN DE CATEGORÍA:\n" + descripcion;
            respuesta += "\n\n:::::::::::::::::::::::::::::::::::::::::::::::::::::::\n";
            respuesta += ":::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";

            int indiceLista = 0;
            foreach (Actividad actividad in unS.Cartelera)
            {
                //FILTRO DE CATEGORIAS 
                if (actividad.Categoria.Id == categoriaFiltro)
                {
                    //FILTRO DE FECHAS
                    if (actividad.DateTimeActividad > fecha1 && actividad.DateTimeActividad < fecha2)
                    {
                        ++indiceLista;
                        respuesta +=  indiceLista + " - Nombre de Actividad: " + actividad.Nombre + "\n";
                        respuesta += "Fecha de actividad: " + actividad.DateTimeActividad.ToShortDateString();

                    }
                     
                }
            }
            Console.WriteLine(respuesta);
            // ACA UN AVISO CON UN UN IF POR SI EL PROGRAMA NO ENCUENTRA  ACTIVIDADES EN LA CATEGORIA/FECHA SOLICITADAS:
            if (indiceLista < 1) {
                Console.WriteLine("Ups! Parece que no hay actividades disponibles para esas fechas en esa categoría."); 
                    }
            
        }


        public static void mostrarActividadesATP()
        {
            string respuesta = "Lista de Actividades Aptas para Todo Público \n";
            foreach (Actividad actividad in unS.Cartelera)
            {
                if (actividad.MinEdad == "P")
                { // AGREGAR FILTRO PARA RANGO DE FECHAS
                    respuesta += "- Nombre de Actividad: " + actividad.Nombre + "\n";
                }
            }
            Console.WriteLine(respuesta);
        }




        static private string ArmoMenu()
        {
            string respuesta = "";
            respuesta += "1- Listar actividades (Ver Cartelera) \n";            
            respuesta += "2- Cambiar Aforo máximo \n";
            respuesta += "3- Cambiar Valor de Precio de Butacas (Lugares abiertos) \n";
            respuesta += "4- Listar actividades para un intervalo de fechas dado \n";
            respuesta += "5- Listar actividades Aptas para Todo Público (P) \n";
            respuesta += "\n";
            respuesta += "0 -Salir\n";
            return respuesta;
        }


        static private void Titulo(string titulo)
        {

            Console.Clear();
            Console.WriteLine(titulo);           
            Console.WriteLine(Linea(titulo));
        }

        static private string Linea(string titulo)
        {
            string linea = "";
            for (int i = 0; i < titulo.Length; i++)
            {
                linea += "-";
            }
            return linea;
        }

        //// metodo encargado de cambiar el porcentaje de aforo:
        //public static void cambiarAforoMax(int valueParam)
        //{
        //    unS.AforoMax = valueParam;
        //    Console.WriteLine("\n" + "Se ha cambiado aforo máximo. Ahora el aforo máximo es de " + unS.AforoMax + " personas .");
        //}


    }
}