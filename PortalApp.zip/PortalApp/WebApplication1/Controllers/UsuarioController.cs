﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ObligatorioP2;
using Microsoft.AspNetCore.Http;

namespace WebApplication1.Controllers
{
    public class UsuarioController : Controller
    {
        Sistema unS = Sistema.Instancia;
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Registro()
        {
            ViewBag.usuariosRegistrados = unS.UsuariosRegistrados;
            return View(new Usuario());
        }

        public IActionResult Ver(Usuario nuevoUsuario)
        {
            // POR AHORA, RETORNA UNA VISTA CON LA INFO SACADA DESDE EL FORM
            ViewBag.nuevoUsuarioNombre = nuevoUsuario.Nombre;
            ViewBag.nuevoUsuarioApellido = nuevoUsuario.Apellido;
            ViewBag.nuevoUsuarioEmail = nuevoUsuario.Email;
            ViewBag.nuevoUsuarioFecha = nuevoUsuario.FechaNac;
            ViewBag.nuevoUsuarioNombreUsuario = nuevoUsuario.NombreUsuario;
            ViewBag.nuevoUsuarioPassword = nuevoUsuario.Password;
            return View();
        }

        [HttpPost]
        public IActionResult Registro(Usuario nuevoUsuario)
        {
            // ACTION PARA GUARDAR EL USUARIO NUEVO, WIP
            nuevoUsuario.Rol = "Cliente";
            if (unS.AgregarUsuario(nuevoUsuario))
            {
                return RedirectToAction("ver", nuevoUsuario);
            }

            return View(nuevoUsuario);
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string nombreusuario, string password)
        {
            Usuario usuarioEncontrado = unS.BuscarUsuarioNombre(nombreusuario);
            if (usuarioEncontrado == null || usuarioEncontrado.Password != password)
            {
                ViewBag.Mensaje = "Datos incorrectos";
                return View();
            }

            HttpContext.Session.SetString("rol", usuarioEncontrado.Rol);
            HttpContext.Session.SetString("nombre", usuarioEncontrado.Nombre);
            HttpContext.Session.SetInt32("id", usuarioEncontrado.Id);
            HttpContext.Session.SetString("username", usuarioEncontrado.NombreUsuario);

            return Redirect("/actividad/index");
        }

        public IActionResult VerClientes()
        {
            List<Usuario> clientes = unS.UsuariosRegistrados.OrderBy(usuario => usuario.Apellido).ThenBy(usuario => usuario.Nombre).ToList();
            ViewBag.clientes = clientes;
            return View();
        }
    }
}
